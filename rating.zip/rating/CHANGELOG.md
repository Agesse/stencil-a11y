# PeA11yRating
Tous les changements du plugin JQuery PeA11yRating seront mis dans ce fichier.

## Unreleased - 2018-07-09
### Ajouts
- Comportement au clavier conforme au role aria slider

## Unreleased - 2018-07-06
### Ajouts
- Affichage des elements selon un "max" surchargeable
- Valeur recuperable via une fonction
- Valeur changeable via une fonction
- Valeur au survol recuperable via une fonction
- Si click sur la valeur en cours, reset le composant si l'options est active
- Template customisable
- Classe au hover du composant
- Le passage de la souris change le template affiche
- Ajout des labels NVDA

